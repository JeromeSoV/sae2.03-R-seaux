Pour convertir notre fichier .md en .html :
    télécharger pandoc
    utiliser la commande pandoc src/rapport.md -o src/rapport.html -c ../ressources/CSS.css -s --toc

Pour convertir notre fichier .html en .pdf :
    utiliser la commande pandox src/rapport.html -o src/rapport.pdf